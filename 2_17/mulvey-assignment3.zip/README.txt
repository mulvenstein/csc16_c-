INSTRUCTIONS : 

on unix:
  1) unzip .zip
  2) make sure g++ is installed
  3) write into console (make sure youre in correct directory)
     ./baseConvert.out
  OR to compile and run
  1) open up terminal
  2) g++ baseConvert.cpp -o baseConvert.out && ./baseConvert.out

on Windows:
  1) open whatever IDE you use
  2) compile and run
