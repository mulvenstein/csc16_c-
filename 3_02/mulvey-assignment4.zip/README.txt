HOW TO RUN:

on unix systems:
	-open terminal
	-navigate to where you downloaded this project
	-type "g++ mulvey-SoE.cpp Sieve.cpp -o exe.out && ./exe.out"

on windows: 
	-open mulvey-SoE with your favorite IDE
	-compile and run